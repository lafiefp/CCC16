﻿namespace Level1
{
    internal class CommandCenter
    {
    }
}